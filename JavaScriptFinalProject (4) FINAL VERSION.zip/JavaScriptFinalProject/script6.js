var totalPrice = 0 //price for all orders

function nameConfirm() {
    let fName = document.getElementById("firstName").value; //getting user firstName input
    let lName = document.getElementById("lastName").value; //getting user lastName input
    let uAddress = document.getElementById("userAddress").value //getting user Address input
    let nameConfirmMSG = "Your Name is: " + fName + " " + lName;
    //let currentTime = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    //document.getElementById("currentTime").value = time;
    let newLine = "\r\n";
    alert(nameConfirmMSG += newLine + "Your Address is: " + uAddress); //outputting credentials
}
function contactMethodConfirm() {
    let optionMethod = document.querySelector('input[name = "contactMethod"]:checked').value; //getting contactMethod input (optionMethod)
    if (optionMethod == 'Delivery') {
       alert("You chose to have your order delivered!");
    }
    else if (optionMethod == 'Pick-Up') {
        alert("You chose to pick up your order in store!");
    }
    else if (optionMethod == 'Dine-In') {
        alert("You have chose to Dine In!");
    }
    else {
       alert ("Oops! try again!");
    }
}
function toppingsConfirm() {
    var myArray = []; //array of toppings
    var myPrice = 0; //topping price
    var checkboxes = document.querySelectorAll('input[type=checkbox]:checked'); //getting all selected checkboxes
    let t1 = document.getElementById("checkbox0").value;
    //setting all checkbox values to variables
    let t2 = document.getElementById("checkbox1").value;
    let t3 = document.getElementById("checkbox2").value;
    let t4 = document.getElementById("checkbox3").value;
    let t5 = document.getElementById("checkbox4").value;
    let t6 = document.getElementById("checkbox5").value;
    let t7 = document.getElementById("checkbox6").value;
    let t8 = document.getElementById("checkbox7").value;
    //alert(checkboxes);
    
    //all toppings prices set to variables
    let p1 = 0
    let p2 = .5
    let p3 = .25
    let p4 = .25
    let p5 = .25 
    let p6 = .5
    let p7 = .25
    let p8 = .25
    
    //if checkbox is checked, add topping price to total topping price
    if (document.getElementById("checkbox0").checked) {
        myPrice = myPrice + p1;
    }
    if (document.getElementById("checkbox1").checked) {
        myPrice = myPrice + p2;
    }
    if (document.getElementById("checkbox2").checked) {
        myPrice = myPrice + p3;
    }
    if (document.getElementById("checkbox3").checked) {
        myPrice = myPrice + p4;
    }
    if (document.getElementById("checkbox4").checked) {
        myPrice = myPrice + p5;
    }
    if (document.getElementById("checkbox5").checked) {
        myPrice = myPrice + p6;
    }
    if (document.getElementById("checkbox6").checked) {
        myPrice = myPrice + p7;
    }
    if (document.getElementById("checkbox7").checked) {
        myPrice = myPrice + p8;
    }
    for(i=0; i<checkboxes.length; i++) {
        //pushing checkbox values into topping array
        myArray.push(checkboxes[i].value)
    }
    alert("You have chosen the following toppings: " + "\n" + myArray) //outputting selected toppings
    alert("The Price of These Toppings In Total Is: " + "\n" + myPrice + "$") //outputting total topping price
    totalPrice = totalPrice + myPrice; //adding topping price to total order price
}
function pizzaSizeConfirm() {
    let myList = document.getElementById("pizzaSizeSelect"); //getting list of pizza sizes
    let myPizzaPrice = 0; //pizza size price
    document.getElementById("favorite").value = myList.options[myList.selectedIndex].text; //setting the value of favorite to the user choice from pizza size dropdown
    let pizzaSize = document.getElementById("favorite").value; //setting pizzaSize variable to selected pizza choice
    // outputting selected choice to user, setting pizza price to selected choice.
    if (pizzaSize == "Personal ($8)") {  
        alert("You have chosen Personal Size!")
        myPizzaPrice = 8;
    }
    else if (pizzaSize == "Small ($9)") {
        alert("You have chosen Small Size!")
        myPizzaPrice = 9;
    }
    else if (pizzaSize == "Medium ($10)") {
        alert("You have chosen Medium Size!")
        myPizzaPrice = 10;
    }
    else if (pizzaSize == "Large ($11)") {
        alert("You have chosen Large Size!")
        myPizzaPrice = 11;
    }
    else if (pizzaSize == "Extra Large ($12)") {
        alert("You have chosen Extra Large Size!")
        myPizzaPrice = 12;
    }
    alert("The Price of your pie is: " + myPizzaPrice + "$")
    //totalPrice = totalPrice + myPizzaPrice;
}
function submitForm() {
    //initializing global variables to function
    let fName = document.getElementById("firstName").value;
    let lName = document.getElementById("lastName").value;
    let uAddress = document.getElementById("userAddress").value
    let nameConfirmMSG = "Your Name is: " + fName + " " + lName;
    let optionMethod = document.querySelector('input[name = "contactMethod"]:checked').value;
    let myList = document.getElementById("pizzaSizeSelect");
    let sizeSelect = myList.options[myList.selectedIndex].text;
    //time for order submission page
    let today = new Date();
    let h = today.getHours();
    let m = today.getMinutes();
    let s = today.getSeconds();
    let currentTime = [ h, m, s ].join(':'); //current time variable
    let newLine = "\r\n";
    let selectedString = "";
    alert(nameConfirmMSG += newLine + "Your Address is: " + uAddress); // your address and name alerted
    //if contact method is delivery, add 30 mins to current time for delivery time
    if (optionMethod == 'Delivery') {
        alert("Your contact method for your order is: " + optionMethod + "\r\n" + "It will be delivered in 30 minutes to: " + uAddress);
    }
    else {
        alert("Your contact method for your order is: " + optionMethod);
    }
    //outputting chosen toppings on order submission
    for(i=0; i<=7; i++) {
        if(document.querySelector('input[name=checkbox' + i +']:checked')) {
            alert("You have chosen the following topping for your pizza: " + document.getElementById("checkbox" + i).value);
            }
        }
    alert("Your pizza will be: " + sizeSelect + " Size"); //alerting pizza size
    alert("The Total Price of your order is: " + "\n" + totalPrice + "$"); //alerting total price for all orders
    let x = confirm("Would you like to submit your order?") //confirmation of submission
    if (x == true) {
        //if order is submitted, display new page
        document.write("Your order was submitted at: " + currentTime + "<br>" + "Thank You " + fName + "!"
        + "<br>" + "Your order was placed on: " + today.toLocaleDateString() + "<br>" + "The Total of Your Order is: " + totalPrice + "$");
    }
    else {
        //order canceled statement
        alert("You have canceled the order submission")
        localStorage.clear();
    }
    //alert(x)
}